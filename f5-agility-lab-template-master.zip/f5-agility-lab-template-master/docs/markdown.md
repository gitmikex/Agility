Markdown files are also supported
=================================

We also support [Markdown!](http://commonmark.org/help/)

Follow these steps to complete this task:

1. Step 1

   ![Screenshot 1](_static/image001.png)

2. Step 2

3. Step ...

4. Step n

