Lab – Install a |bip| |ve| image on a Hypervisor
------------------------------------------------

.. TODO:: Needs lab description

In the previous lab we learned how to download the |bip| |ve| image.  Now, we
can install the image onto a hypervisor.

Task – Upload the image to your Hypervisor
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. TODO:: Needs task description

In this task you will upload the image to your hypervisor.

Follow these steps to complete this task:

.. rst-class:: task-stepsx

#. Open your hypervisor management console
#. Figure out how to upload the image

   .. ERROR:: These are bad instructions...

#. Great!  You're done

Task – Start a |bip| |ve| Instance
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. TODO:: Needs task description

In this task we will start and instance of |bip| using the image uploaded in
the previous task.

Follow these steps to complete this task:

#. Open your hypervisor management console
#. Click the |bip| image
#. Click the 'Start' button (or it's equivalent)
