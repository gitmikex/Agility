Lab – Power-on the |bip| Appliance
----------------------------------

.. TODO:: Needs lab description

In this lab we will connect the power cord and turn on the |bip| Appliance.

Task – Connect the Power Cord
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. TODO:: Needs task description

In this task you will connect the appropriate power cord.

.. IMPORTANT:: Be sure to use the appropriate power cord for your region.
   Follow all applicable electrical guidelines and codes.

Follow these steps to complete this task:

#. Connect one end to the |bip|
#. Connect the other end to the power source

Task – Turn on the |bip| Appliance
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. TODO:: Needs task description

In this task you turn on the |bip| Appliance.

Follow these steps to complete this task:

#. Push the 'On' button
#. Verify the red F5 ball lights up
