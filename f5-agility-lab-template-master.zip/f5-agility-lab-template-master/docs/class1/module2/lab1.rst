Lab – Install a |f5| |bip| Appliance
------------------------------------

.. TODO:: Needs lab description

In this lab we will unpack and install the |bip| Appliance into a rack in your
datacenter.

Task – Unpack the |bip| Appliance
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. TODO:: Needs task description

In this task you will remove the |bip| Appliance from it's packaging.

Follow these steps to complete this task:

#. Open the box with an extremely sharp knife or cutter

   .. DANGER:: Knives are sharp and can cut you.  Please be careful.

      |knivessharp|

#. Carefully remove the |bip| from it's packaging
#. Set it down on a stable surface

Task – Install the |bip| Appliance in a Datacenter Rack
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. TODO:: Needs task description

In this task you will install the |bip| Appliance into a Rack.  You will need
the following tools:

- Phillips Screwdriver
- Hammer
- Crowbar

.. CAUTION:: Appliances can be heavy.  Please follow all applicable safety
   guidelines.

Follow these steps to complete this task:

#. Install the rackmount rails onto the appliance using the included hardware
#. Lift the appliance into place
#. Complete installation by using your tools to secure the appliance.

.. |knivessharp| image:: http://theinkkitchen.com/wp-content/uploads/2014/08/Screenshot-2014-07-30-12.22.44.png
