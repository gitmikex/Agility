Class - |classname|
===================

.. TODO:: Need class description

This class covers the following topics:

- Downloading a |f5| |bip| |ve|
- Installing a |bip| |ve| image on a hypervisor
- Installing a |f5| |bip| Appliance
- Powering on a |bip| Appliance

Expected time to complete: **3 hours**

.. toctree::
   :maxdepth: 1
   :glob:

   module*/module*